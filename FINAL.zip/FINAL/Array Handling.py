""" Short, one line description of the module ending with a period.
A longer description of the module with details that may help the user or anybody
reviewing the code later. make sure you outline in detail what the module does and how it can be used.
"""

__author__ = "Matthew Johnson"
__license__ = "GPL"
__version__ = "1.0.2"
__email__ = "matthew.johnson111@education.nsw.com.au"
__status__ = "Prototype"


""" revision notes:


"""

#include statements
from mods import *

#other setup stuff

#now the real stuff we came here for
def main():
    loadArray()

if __name__ == '__main__':
    main()    

        

        
while True:
    main()
    
