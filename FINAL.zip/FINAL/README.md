# Skills
This repository will hold your work through the year in separate branches. The work will take a modular approach and gradually build over the course of the year.

Your tasks will be described in Stile. For each task open a new branch. Give each branch a name that corresponds to the task name. To let me know you are finished or to discuss problems you are having, raise a pull request.

This approach is very much a work in progress for me too, so this README file may change and you will neet to update it.
