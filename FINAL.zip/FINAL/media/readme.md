This folder is to hold all your images, sound and other media
